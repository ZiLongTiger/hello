package com.test;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.dao.CourseDao;
import com.dao.StudentDao;
import com.entity.Student;


@RunWith(SpringJUnit4ClassRunner.class) //ʹ��Springtest���Կ��
@ContextConfiguration("/Spring.xml") //��������
public class StudentTest {

	@Autowired
	private StudentDao stuDao;
	
	@Autowired
	private CourseDao courseDao;
	
	@Test
	public void queryAll() {
//		System.out.println(stuDao.queryAllStudent());
//		System.out.println(courseDao.queryAllCourse());
		System.out.println(courseDao.getCourse(2));
	}
	
	@Test
	public void testUpdateStu() {
		Student student = stuDao.getStudent(6);
		student.setAge(123);
		stuDao.updateStu(student);
		Student student2 = stuDao.getStudent(6);
		System.out.println(student2);
	}
}
