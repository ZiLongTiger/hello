package com.dao;

import java.util.List;

import com.entity.Course;

public interface CourseDao {

	public List<Course> queryAllCourse();
	
	public Course getCourse(Integer id);
}
