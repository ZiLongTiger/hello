package com.dao;

import java.util.List;

import com.entity.StudentVO;
import com.entity.Student;

public interface StudentDao {

	public List<Student> queryAllStudent();
	
	public Student getStudent(Integer id);
	
	public Student getStudentByName(String name);
	
	public int save(StudentVO stu);
	
	public int deleteStu(Integer id);
	
	public int updateStu(Student stu);
	
	public List<Student> queryByCid(Integer cid);
}
