package com.service;

import java.util.List;

import com.entity.StudentVO;
import com.entity.Student;

public interface StudentService {

	public List<Student> queryAllStudent();
	
	public int save(StudentVO stu);

	public Student getStudent(Integer id);
	
	public Student getStudentByName(String name);
	
	public int deleteStu(Integer id);
	
	public int updateStu(Student stu);
	
	public List<Student> findStudnetByCid(Integer cid);
}
