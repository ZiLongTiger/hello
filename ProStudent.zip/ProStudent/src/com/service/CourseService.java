package com.service;

import java.util.List;

import com.entity.Course;

public interface CourseService {
	public List<Course> queryAllCourse();
	
	public Course getCourse(Integer id);
}
