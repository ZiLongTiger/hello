package com.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.StudentDao;
import com.entity.StudentVO;
import com.entity.Student;
import com.service.StudentService;

@Service("studentService")
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentDao stuDao;
	@Override
	public List<Student> queryAllStudent() {
		return stuDao.queryAllStudent();
	}

	@Override
	public Student getStudent(Integer id) {
		return stuDao.getStudent(id);
	}

	@Override
	public int save(StudentVO stu) {
		return stuDao.save(stu);
	}

	@Override
	public int deleteStu(Integer id) {
		return stuDao.deleteStu(id);
	}

	@Override
	public int updateStu(Student stu) {
		return stuDao.updateStu(stu);
	}

	@Override
	public Student getStudentByName(String name) {
		return stuDao.getStudentByName(name);
	}

	@Override
	public List<Student> findStudnetByCid(Integer cid) {
		return stuDao.queryByCid(cid);
	}

}
