package com.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.CourseDao;
import com.entity.Course;
import com.service.CourseService;

@Service("courseService")
public class CourseServiceImpl implements CourseService {

	@Autowired
	private CourseDao courseDao;
	
	@Override
	public List<Course> queryAllCourse() {
		return courseDao.queryAllCourse();
	}

	@Override
	public Course getCourse(Integer id) {
		return courseDao.getCourse(id);
	}



}
