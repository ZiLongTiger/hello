package com.entity;

import java.util.Date;

public class StudentVO {

	private String name;
	
	private String password;
	
	private Integer age;
	
	private Date registration;
	
	private Integer cid;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public Date getRegistration() {
		return registration;
	}

	public void setRegistration(Date registration) {
		this.registration = registration;
	}

	public Integer getCid() {
		return cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public StudentVO(String name, String password, Integer age, Date registration, Integer cid) {
		super();
		this.name = name;
		this.password = password;
		this.age = age;
		this.registration = registration;
		this.cid = cid;
	}

	@Override
	public String toString() {
		return "AddStudent [name=" + name + ", password=" + password + ", age=" + age
				+ ", registration=" + registration + ", cid=" + cid + "]";
	}
	
}
