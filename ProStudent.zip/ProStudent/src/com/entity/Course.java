package com.entity;

public class Course {

	private Integer cId;
	
	private String name;

	public Course() {
		super();
	}

	public Integer getcId() {
		return cId;
	}

	public void setcId(Integer cId) {
		this.cId = cId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Course [cId=" + cId + ", name=" + name + "]";
	}
}
