package com.controller;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.entity.StudentVO;
import com.alibaba.fastjson.JSON;
import com.entity.Course;
import com.entity.Student;
import com.service.CourseService;
import com.service.StudentService;
import com.utils.App;

@Controller("centerController")
public class CenterController {

	@Resource(name="studentService")
	private StudentService stuService;
	
	@Resource(name="courseService")
	private CourseService courseService;
	
	@RequestMapping("queryAll.do")
	public String findAllStudent(Model model) {
		List<Student> list = stuService.queryAllStudent();
		List<Course> courseList = courseService.queryAllCourse();
		model.addAttribute("data", list);
		model.addAttribute("course", courseList);
		return "show";
	}
	
	@RequestMapping("change.do")
	public String changePage(Model model) {
		List<Course> list = courseService.queryAllCourse();
		String str = "add";
		model.addAttribute("msg", str);
		model.addAttribute("data", list);
		return "input";
	}
	
	@RequestMapping("add.do")
	public String add(HttpServletRequest req,Model mpdel) throws IOException {
		req.setCharacterEncoding("utf-8");
		String name = req.getParameter("stuName");
		if(name==null ||  name.equals("")) {
			return "redirect:change.do";
		}
		String password = req.getParameter("password");
		password = App.md5(password);
		Integer age = Integer.parseInt(req.getParameter("age"));
		String cid = req.getParameter("course");
		Integer id = Integer.parseInt(cid);
		StudentVO stu = new StudentVO(name, password, age, new Date(), id);
		System.out.println(stu);
		int res = stuService.save(stu);
		if(res > 0) {
			return "redirect:queryAll.do";
		}else {
			return "redirect:change.do";
		}
		
	}
	
	@RequestMapping("delete.do")
	public String deleteStudent(HttpServletRequest req) {
		Integer id = Integer.parseInt(req.getParameter("id"));
		stuService.deleteStu(id);
		return "redirect:queryAll.do";
	}
	
	@RequestMapping(value="delete2.do",method=RequestMethod.POST)
	@ResponseBody
	public String delteStu(HttpServletRequest req) {
		Integer id = Integer.parseInt(req.getParameter("id"));
		int res = stuService.deleteStu(id);
		String msg = res+"";
		return msg;
	}
	
	@RequestMapping("querySingle.do")
	public ModelAndView querySingle(HttpServletRequest req) {
		ModelAndView mv = new ModelAndView();
		Integer id = Integer.parseInt(req.getParameter("id"));
		System.out.println(id);
		Student student = stuService.getStudent(id);
		System.out.println(student);
		List<Course> list = courseService.queryAllCourse();
		String str = "update";
		mv.addObject("msg", str);
		mv.addObject("student", student);
		mv.addObject("data", list);
		mv.setViewName("input");
		return mv;
	}
	
	@RequestMapping("queryByName.do")
	@ResponseBody
	public String queryByName(String stuName) {
		System.out.println(stuName);
		Student stu = stuService.getStudentByName(stuName);
		String date = "";
		if(stu != null) {
			date="success";
		}
		return date;
	}
	
	@RequestMapping("update.do")
	public String updateStu(HttpServletRequest req) throws IOException {
		req.setCharacterEncoding("utf-8");
		Integer id = Integer.parseInt(req.getParameter("id"));
		Student student = stuService.getStudent(id);
		Integer age = Integer.parseInt(req.getParameter("age"));
		Integer cid = Integer.parseInt(req.getParameter("course"));
		Course course = courseService.getCourse(cid);
		student.setAge(age);
		student.setCourse(course);
		System.out.println(course);
		stuService.updateStu(student);
		return "redirect:queryAll.do";
	}
	
	@RequestMapping("course.do")
	@ResponseBody
	public String findStudnetByCid(Model model, HttpServletRequest req) {
		Integer cid = Integer.parseInt(req.getParameter("cid"));
		List<Student> list = stuService.findStudnetByCid(cid);
		System.out.println(list);
		Object json = JSON.toJSON(list);
		return ""+json;
	}
}
